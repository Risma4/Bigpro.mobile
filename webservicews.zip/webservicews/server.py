#https://github.com/Risma4/Bigpro.mobile

# RISMA NIANKUPANDANG - 19090083 - 6B
# MULYANA PUTRIYANI - 19090113 - 6D

from flask import Flask
from flask_restful import Api
from PredictNews import PredictNews

app = Flask(__name__)
api = Api(app)

api.add_resource(PredictNews, '/news')

if __name__ == '__main__':
    app.run(debug=True)