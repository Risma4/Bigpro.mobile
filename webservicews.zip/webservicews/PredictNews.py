from flask_restful import reqparse, Resource
import xgboost
import numpy as np
import json


class PredictNews(Resource):
    def __init__(self, model_path='model2.pkl'):

        # setup the parser for getting game arg
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('news', type=str)

        # initialize a model and load the saved weights
        self.model = xgboost.XGBRegressor()
        self.model.load_model(model_path)

    def get(self):
        # parse the args
        args = self.parser.parse_args()

        # extract the 'game' arg and pre-process 
        # to fit the shape the model expects
        news = self.__process_game(args['news'])

        # make prediction
        prediction = self.model.predict(news)

        # return dictionary containing the prediction
        return {'prediction': str(prediction[0])}

    def __process_game(self, news):
        # model expects a 2d np array
        news = np.array(json.loads(news))
        news = np.array([news])
        return news