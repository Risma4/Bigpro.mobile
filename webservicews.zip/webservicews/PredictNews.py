from flask_restful import reqparse, Resource
import xgboost
import numpy as np
import json


class PredictNews(Resource):
    def __init__(self, model_path='model2.pkl'):

       
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('news', type=str)

        
        self.model = xgboost.XGBRegressor()
        self.model.load_model(model_path)

    def get(self):
        
        args = self.parser.parse_args()

        news = self.__process_game(args['news'])

   
        prediction = self.model.predict(news)

       
        return {'prediction': str(prediction[0])}

    def __process_game(self, news):
        
        news = np.array(json.loads(news))
        news = np.array([news])
        return news